Name: YUEN Ho Shing
UID: 3035930943

Implemented features: 
- Successfully implemented all functions, including rgb2gray, smooth2D, and harris detection